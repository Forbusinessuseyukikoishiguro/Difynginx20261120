#!/usr/bin/env bash
# 使い方: bash build.sh <作業フォルダ>   （作業フォルダに spec.js を置く。head.js・body.js はこのassetsのものを使う）
set -e
A="$(cd "$(dirname "$0")" && pwd)"; D="$(cd "$1" && pwd)"
cat "$A/head.js" "$A/body.js" "$A/layouts_ext.js" "$A/render.js" > "$D/build.js"
(cd "$D" && DRILL_DIR="$D" node build.js)
PPTX="$(ls -t "$D"/*.pptx | head -1)"
python3 /mnt/skills/public/pptx/scripts/office/validate.py "$PPTX" | tail -1
(cd "$D" && soffice --headless --convert-to pdf "$PPTX" >/dev/null 2>&1; mkdir -p png; rm -f png/*; pdftoppm -r 40 -png *.pdf png/s)
python3 -I - "$D" <<'P'
import sys, glob
from PIL import Image
d = sys.argv[1]; f = sorted(glob.glob(d + '/png/s-*.png')); im = [Image.open(x) for x in f]; w, h = im[0].size
for k in range(0, len(im), 12):
    sh = Image.new('RGB', (w * 3, h * 4), 'white')
    for i, m in enumerate(im[k:k + 12]): sh.paste(m, ((i % 3) * w, (i // 3) * h))
    sh.save(f'{d}/png/sheet{k // 12}.png')
print('contact sheets:', d + '/png/sheet*.png  → 目視で、表と下の帯の重なりを確認する')
P
