# Dify nginx 更新講座（nginxだけ入れ替える）一式

うさうさ研修工房｜公式確認日 2026-11-20

脆弱性診断で Dify（Docker Compose）の nginx を指摘されたとき、Dify 本体は更新せず、nginx だけを戻れる形で入れ替える講座。

## 中身

1. `Dify_nginx更新講座_講師用.pptx`：21枚（スピーカーノート付き。設計値 95分・目安）
2. `Dify_nginx更新講座_受講生用.pptx`：21枚（ノート無し）
3. `Dify nginx更新講座_講師台本.md`：スライド番号・問い・時刻をPPTと一致
4. `Dify nginx更新講座_受講生用テキスト.md`
5. `Dify nginx更新講座_ナレーション全文.md`：動画用（⏸合計 440秒）
6. `code/`：nginx_check.py、試験7件、override の例、README

## 確認したこと／未確認のこと

確認したこと：公式ページの確認／nginx_check.py の試験7件（ダミー入力）／override ファイルの自動読み込み（Compose v5.6.1 の config）／PPT 21枚の検証と画像確認。

未確認のこと：実際の Dify 環境での入れ替え（作成環境に Docker のデーモンが無い）／サービス指定 up の再作成の挙動（公式に明記を確認できず）／Dify 公式の nginx 単独更新手順／HTTPS・certbot 構成／勧告の個別内容（講座では固定しない）。

版の数字は、すべて例（ダミー）。実施時に nginx 公式で確認する。
