# 書き込み式ドリル・ヒアリング スキル パック

うさうさ研修工房｜作成日 2026-11-19（同日、事前ヒアリングと書き込みパターンを追加）

講座の内容から、受講生が自分で書き込む**ドリルPPT**（問題＋解答と解説）を作るためのSkillと、そのまま動くビルドキットです。

## 0. 3つのSkill

1. `usausa-ppt-writein-drill-builder`：書き込み式ドリル（問題＋解答）。ビルドキットはここの assets
2. `usausa-pre-hearing-sheet-builder`：研修の前に、お客様が書く事前ヒアリングシート＋回収後の整理表（追加）
3. `usausa-writein-pattern-catalog`：書き込みの型13種の選び方と、データの形（追加）

3つとも、同じビルドキット（`usausa-ppt-writein-drill-builder/assets`）を使う。

## 1. 中身

1. `usausa-ppt-writein-drill-builder/SKILL.md`：Skill本体（原則・5つの型・手順・落とし穴・品質チェック）
2. `usausa-ppt-writein-drill-builder/assets/head.js`・`body.js`：スライドを作るキット（pptxgenjs）
3. `usausa-ppt-writein-drill-builder/assets/spec.example.js`：サンプルのspec（24枚のドリル。Dify×Azure音声ボット講座）
4. `usausa-ppt-writein-drill-builder/assets/build.sh`：ビルド → 検証 → PDF → PNG一覧
5. `assets/layouts_ext.js`：追加の書き込みレイアウト7種（wmatch・wsort・wscale・wbins・wcode・wcase・wchoice）。`render.js` は描画の最後の部分
6. `assets/spec.hearing.example.js`：事前ヒアリングシートの雛形（11枚）／`assets/spec.patterns.example.js`：全パターンの最小例（10枚）
7. `usausa-pre-hearing-sheet-builder/SKILL.md`・`usausa-writein-pattern-catalog/SKILL.md`
8. `sample/`：ドリル見本（24枚）・事前ヒアリングシート見本・書き込みパターン見本・回収後整理表の見本（md）

## 2. Skillの入れ方

1. Claude の設定で、`usausa-ppt-writein-drill-builder` フォルダ（または SKILL.md）を、Skillとして追加する
2. 会話で「書き込み式ドリルを作って」「ドリルPPT」と頼むと、使われる
3. 会話に、元の講座（PPT・台本）を添えると、設問を講座の内容から作る

## 3. ビルドキットの使い方（単独でも使える）

必要なもの：Node.js（pptxgenjs）、Python（python-pptx・Pillow）、LibreOffice（PDF化）、`/mnt/skills/public/pptx` のスクリプト（apply_theme.js・validate.py）。

```bash
mkdir work && cp usausa-ppt-writein-drill-builder/assets/spec.example.js work/spec.js
# work/spec.js を、自分の講座の設問に書き換える
bash usausa-ppt-writein-drill-builder/assets/build.sh work
# → work/ にPPTX・PDF・png/sheet*.png（目視用の一覧）ができる
```

0. 見本のビルド：`spec.hearing.example.js` または `spec.patterns.example.js` を、work/spec.js に置いて同じ手順
1. `DRILL_OUT` 環境変数で、出力のファイル名を変えられる
2. 表紙・フッター・地図の文言は、spec.js の `META` で変える

## 4. 作るドリルの型

1. A 穴埋め（数字・言葉）
2. B ○×（理由を一言）
3. C 流れの並べ替え・再試行などの規則
4. D 症状から利用者への言葉、ノード・設定
5. E 設計（長い入力・残る場所・未確認を確認する計画・指示文）
6. 解答と解説（根拠の札と、戻る講座スライド番号つき）

## 5. 守っていること

1. 設問と解答は、講座で確認した公式の事実と、講師の整理だけから作る（札：公式／整理／確認／未確認）
2. 合格ラインの数値は設けない
3. 秘密（キー・トークン・本物の音声や個人情報）を書かせない
4. 未確認のことは、「未確認と書くのが正解」の設問にする

## 6. 確認したこと／未確認のこと

確認したこと：

1. ビルドキットを別のフォルダで単独実行し、24枚のドリルが作れて、検証に通ること（レイアウト追加後も同じ）。
2. 事前ヒアリング（11枚）と書き込みパターン見本（10枚）が、作れて、検証に通り、画像で重なり・はみ出しが無いこと。
3. 見本のドリル24枚を、画像で目視したこと。

未確認のこと：

1. 追加7レイアウトの、PowerPoint以外のアプリでの見え方。wscale の丸を塗る操作、wchoice の□を■にする操作の使い勝手（お客様に1回書いてもらって確かめる）。
2. 実際のお客様のヒアリングでの、質問の過不足。
3. Skillとして保存したときの、自動起動のされ方（Claudeの画面で保存して試す）。
4. Dify×Azure以外の題材でのドリル作成（次の題材で試す）。

## 7. 次の一手

次の講座で1本作り、落とし穴の欄に、見つけたものを足してください。
