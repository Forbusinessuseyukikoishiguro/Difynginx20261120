const list = SPEC;
list.forEach(sp => R[sp.layout](sp));
require('fs').writeFileSync((process.env.DRILL_DIR || __dirname) + '/spec.json', JSON.stringify({ SPEC }, null, 1));
(async () => {
  const f = (process.env.DRILL_DIR || __dirname) + '/' + (process.env.DRILL_OUT || 'ドリル_受講生用書き込み.pptx');
  await pres.writeFile({ fileName: f }); await applyTheme(f, THEME); console.log('ok', f, list.length);
})();
