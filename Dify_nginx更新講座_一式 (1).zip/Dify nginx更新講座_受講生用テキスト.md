# Dify nginx 更新講座（受講生用テキスト）

公式確認日：2026-11-20。版の数字（1.30.7 など）は、すべて例（ダミー）です。実施するときは、nginx 公式の勧告ページで、直す版を確認してください。

## 1. この講座で、できるようになること

脆弱性診断で、Dify（Docker Compose）の nginx を指摘されたとき、Dify 本体は更新せず、nginx のコンテナだけを、戻れる形で入れ替えられるようになる。

1. 診断の指摘を、「どの版か」「どこのものか」「直す版は何か」に分けて読める
2. 公式（nginx security advisories）で、自分の系列の「直す版」を探せる
3. 版を固定し（override ファイル）、nginx だけを入れ替え、確認し、戻せる
4. 公式で確認したことと、未確認のことを、分けて言える

## 2. 全体の流れ

```mermaid
flowchart LR
  A[1 診断を読む] --> B[2 記録と退避]
  B --> C[3 直す版を決める]
  C --> D[4 版を固定]
  D --> E[5 pull]
  E --> F[6 up -d --no-deps nginx]
  F --> G[7 確認・再診断]
  G -->|問題| H[戻す: タグを旧版へ]
```

## 3. 公式の事実と、講師の整理

| 項目 | 札 | 内容 | 出典 |
|---|---|---|---|
| Dify の nginx は image: nginx:latest | 公式 | docker-compose.yaml の nginx サービスの定義（確認日 2026-11-20） | Dify GitHub（docker/docker-compose.yaml） |
| 設定は、ホスト側のテンプレート等を取り込む | 公式 | volumes に、設定テンプレート・conf.d・SSL のディレクトリ | 同上 |
| 直す版は、勧告ごとの「Not vulnerable」で見る | 公式 | 勧告ごとに、影響を受ける版と受けない版が並ぶ | nginx.org の security advisories |
| latest は mainline 系を指す。stable・完全な版番号のタグもある | 公式 | alpine・slim などの種類もある | Docker Hub 公式 nginx イメージ |
| pull は、SERVICE を指定でき、起動しない | 公式 | docker compose pull SERVICE | Docker docs |
| --no-deps は、リンクされたサービスを起動しない | 公式 | docker compose up のオプション | Docker docs |
| image のような単一値は、後のファイルが置き換える | 公式 | 結果は docker compose config で確認できる | Docker docs（Merge Compose files） |
| override ファイルで版を固定する | 確認 | Compose v5.6.1 の config で、docker-compose.override.yaml／.yml が自動で読まれ、image が置き換わった | この教材の環境 |
| 本体の yaml を直さず、別ファイルにする | 整理 | Dify 本体の更新で、衝突を避けるため | 講師の整理 |
| 系統（stable／mainline、Debian／Alpine）を保つ | 整理 | 別の問題が出うるため | 講師の整理 |
| 入れ替えの確認5項目 | 整理 | 版・起動・応答・ログ・再診断 | 講師の整理 |

## 4. ハンズオン

注意：以下は、ダミーの設定で試す。本物の `docker compose config` の出力は、秘密を含むため、人に見せない・Git に入れない。

1. 版を固定する override ファイルを作る（`docker/docker-compose.override.yaml`）。数字は例。

   ```yaml
   services:
     nginx:
       image: nginx:1.30.7
   ```

2. 設定を保存して、image を確認する。

   ```bash
   docker compose config > config.txt
   python nginx_check.py --compose-config config.txt
   ```

3. nginx のイメージだけを取得する（起動はしない）。

   ```bash
   docker compose pull nginx
   ```

4. 判定する。直す版は、公式で確認した値を渡す。

   ```bash
   python nginx_check.py --version "nginx version: nginx/1.30.4" --fixed 1.30.7 1.31.9
   ```

5. 入れ替える。

   ```bash
   docker compose up -d --no-deps nginx
   docker compose ps --all
   docker compose exec nginx nginx -v
   ```

6. 確認する（版・起動・応答・ログ・再診断）。

## 5. 戻し方

1. override のタグを、記録した旧版に戻す
2. `docker compose up -d --no-deps nginx`
3. `nginx -v` と、画面の表示を確認する

## 6. うまくいかないとき（講師の整理）

| 症状 | 原因の候補 | 最初の確認 |
|---|---|---|
| nginx が起動しない | 設定の誤り・版の差 | `docker compose logs nginx` |
| 画面が出ない（502 など） | api・web が起動していない | `docker compose ps --all` |
| 版が戻っている | override が読まれていない | `docker compose config` で image を見る |
| 指摘が消えない | 別の部品・別の機器の指摘 | 診断の対象と場所を読み直す |

## 7. セキュリティ

1. `docker compose config` の出力、.env、証明書の鍵は、誰にも見せない
2. 診断レポートも、社外に出さない
3. 試すのは、ダミー設定（このテキストのコード例）まで。本番での実施は、お客様の承認と手順書に従う

## 8. 自己チェック（5問）

1. 診断の指摘で、まず確認する3つは？
2. 「直す版」は、どこで決める？
3. 本体の yaml を直さず、override にする理由は？
4. up に --no-deps を付けるのは、なぜ？
5. 版が上がったのに、指摘が残るのは、どんなとき？

答えの目安：1. 版・場所・直す版。2. nginx 公式の勧告ページで、自分の系列の「Not vulnerable」の版。3. Dify 本体の更新で、自分の変更が衝突・消失するのを避けるため。4. リンクされたサービスを起動しないため（公式）。5. 別の部品・別の機器の指摘のとき。

## 9. 確認したこと／未確認のこと

確認したこと：

1. 公式ページを、2026-11-20 に読んだ
2. nginx_check.py を、ダミー入力で実行し、試験7件に成功した
3. override ファイルが自動で読まれることを、Compose v5.6.1 の config で確認した

未確認のこと：

1. 実際の Dify 環境での、nginx の入れ替え
2. サービスを指定した up の、再作成の挙動（公式ページに明記を確認できなかった）
3. Dify 公式の、nginx 単独更新の手順
4. HTTPS・certbot 構成での動作
5. 勧告の個別の内容（講座では固定しない。原文で確認）

## 10. 出典

1. nginx security advisories：https://nginx.org/en/security_advisories.html
2. Docker Hub 公式 nginx イメージ：https://hub.docker.com/_/nginx
3. Dify docker-compose.yaml：https://github.com/langgenius/dify/blob/main/docker/docker-compose.yaml
4. docker compose pull／up：https://docs.docker.com/reference/cli/docker/compose/
5. Merge Compose files：https://docs.docker.com/compose/how-tos/multiple-compose-files/merge/
