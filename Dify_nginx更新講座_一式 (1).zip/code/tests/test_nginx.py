import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
from nginx_check import parse_version, parse_fixed, judge, classify_tag, find_nginx_image, main

FIXED = parse_fixed(["1.30.7", "1.31.9"])  # ダミー例。実際は公式で確認した値を渡す


def test_parse_version():
    assert parse_version("nginx version: nginx/1.30.4") == (1, 30, 4)
    assert parse_version("なにもない") is None


def test_judge_update_ok_unknown():
    assert judge((1, 30, 4), FIXED)["status"] == "update"
    assert judge((1, 30, 7), FIXED)["status"] == "ok"
    assert judge((1, 31, 10), FIXED)["status"] == "ok"
    assert judge((1, 28, 0), FIXED)["status"] == "unknown"   # 系列が渡されていない
    assert judge(None, FIXED)["status"] == "unknown"


def test_fixed_format():
    try:
        parse_fixed(["1.30"])
        assert False
    except ValueError:
        pass


def test_tag_kinds():
    assert classify_tag("nginx:latest")["kind"] == "floating"
    assert classify_tag("nginx")["kind"] == "floating"
    assert classify_tag("nginx:stable")["kind"] == "floating"
    assert classify_tag("nginx:1.30.7")["kind"] == "pinned"
    assert classify_tag("nginx:1.30.7-alpine")["kind"] == "pinned"
    assert classify_tag("nginx:1.30")["kind"] == "other"


CFG = """name: docker
services:
  api:
    image: example/api:1.0
    environment:
      SECRET_KEY: supersecret123
  nginx:
    image: nginx:1.30.7
    environment:
      NGINX_PORT: "80"
volumes: {}
"""


def test_find_image():
    assert find_nginx_image(CFG) == "nginx:1.30.7"
    assert find_nginx_image("services:\n  api:\n    image: x\n") is None


def test_no_secret_leak(tmp_path, capsys):
    p = tmp_path / "c.yaml"
    p.write_text(CFG, encoding="utf-8")
    rc = main(["--compose-config", str(p)])
    out = capsys.readouterr().out
    assert rc == 0 and "supersecret123" not in out and "SECRET_KEY" not in out


def test_exit_codes(capsys):
    assert main(["--version", "nginx/1.30.4", "--fixed", "1.30.7"]) == 1
    assert main(["--version", "nginx/1.30.7", "--fixed", "1.30.7"]) == 0
    assert main(["--version", "nginx/1.28.0", "--fixed", "1.30.7"]) == 2
    assert main([]) == 2
