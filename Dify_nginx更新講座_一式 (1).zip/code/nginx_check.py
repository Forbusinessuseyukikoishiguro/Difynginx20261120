"""Dify の nginx の版が、直す版（修正済みの版）に達しているかを判定する。
読むだけ。ファイルは書き換えない。docker は呼ばない。
docker compose config の出力には秘密が含まれることがあるため、nginx の image 行以外は表示しない。
直す版は、nginx 公式の security advisories ページで自分が確認した値を、引数で渡す（このツールは版の一覧を持たない）。"""
import re
import sys
from pathlib import Path

VER = re.compile(r"nginx/(\d+)\.(\d+)\.(\d+)")
FLOATING = {"latest", "stable", "mainline"}


def parse_version(text):
    """`nginx -v` の出力（例: nginx version: nginx/1.30.4）から (主, 副, 修) を取る。無ければ None。"""
    m = VER.search(text)
    return tuple(int(x) for x in m.groups()) if m else None


def parse_fixed(items):
    """'1.30.7' のような文字列を (1,30,7) にする。形式が違えば ValueError。"""
    out = []
    for s in items:
        p = s.split(".")
        if len(p) != 3 or not all(x.isdigit() for x in p):
            raise ValueError(f"直す版は X.Y.Z の形で渡す: {s}")
        out.append(tuple(int(x) for x in p))
    return out


def judge(version, fixed):
    """系列（主.副）が同じ『直す版』と比べる。系列が無ければ unknown（手で確認）。"""
    if version is None:
        return {"status": "unknown", "reason": "版を読み取れなかった"}
    same = [f for f in fixed if f[:2] == version[:2]]
    if not same:
        return {"status": "unknown", "reason": "同じ系列の直す版が渡されていない。公式で確認して渡す"}
    need = max(same)
    if version >= need:
        return {"status": "ok", "reason": "直す版以上"}
    return {"status": "update", "reason": "直す版より古い: " + ".".join(map(str, need)) + " 以上が必要"}


def classify_tag(image):
    """image 行のタグを分類する。floating は、pull するたびに指す版が変わりうる。"""
    name, _, tag = image.partition(":")
    if not tag:
        return {"image": image, "kind": "floating", "note": "タグ無し（latest 扱い）。版が決まらない"}
    if tag in FLOATING:
        return {"image": image, "kind": "floating", "note": f"{tag} は指す版が変わる。版を固定すると、戻しやすい"}
    if re.fullmatch(r"\d+\.\d+\.\d+(-.+)?", tag):
        return {"image": image, "kind": "pinned", "note": "版が固定されている"}
    return {"image": image, "kind": "other", "note": "上のどれでもない。公式のタグ一覧で意味を確認する"}


def find_nginx_image(config_text):
    """docker compose config の出力から、services の nginx の image 行だけを返す。"""
    in_services = in_nginx = False
    for line in config_text.splitlines():
        if re.match(r"^services:\s*$", line):
            in_services = True
            continue
        if in_services and re.match(r"^\S", line):
            in_services = in_nginx = False
        if in_services and re.match(r"^  \S", line):
            in_nginx = line.strip() == "nginx:"
        elif in_nginx:
            m = re.match(r"^    image:\s*(\S+)\s*$", line)
            if m:
                return m.group(1)
    return None


def main(argv):
    import argparse
    ap = argparse.ArgumentParser(description="nginx の版と image タグを判定する（読むだけ）")
    ap.add_argument("--version", help="nginx -v の出力の文字列")
    ap.add_argument("--fixed", nargs="*", default=[], help="直す版（X.Y.Z）。公式で確認した値")
    ap.add_argument("--compose-config", help="docker compose config の出力を保存したファイル")
    a = ap.parse_args(argv)
    code = 0
    if a.compose_config:
        img = find_nginx_image(Path(a.compose_config).read_text(encoding="utf-8"))
        if img is None:
            print("nginx の image 行が見つからない")
            code = 2
        else:
            c = classify_tag(img)
            print(f"image: {c['image']}（{c['kind']}）{c['note']}")
    if a.version is not None:
        v = parse_version(a.version)
        try:
            j = judge(v, parse_fixed(a.fixed))
        except ValueError as e:
            print(e)
            return 2
        shown = ".".join(map(str, v)) if v else "不明"
        print(f"版: {shown} → {j['status']}：{j['reason']}")
        code = max(code, {"ok": 0, "update": 1, "unknown": 2}[j["status"]])
    if not a.compose_config and a.version is None:
        ap.print_usage()
        return 2
    return code


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
