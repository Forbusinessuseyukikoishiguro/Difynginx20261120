# nginx_check.py

Dify の nginx の版が、「直す版」に達しているかを判定する（読むだけ。docker は呼ばない）。

```bash
python nginx_check.py --compose-config config.txt
python nginx_check.py --version "nginx version: nginx/1.30.4" --fixed 1.30.7 1.31.9
```

1. 直す版は、nginx 公式の勧告ページで確認した値を、引数で渡す（ツールは版の一覧を持たない）
2. 終了コード：0=ok、1=update、2=unknown
3. config の出力は秘密を含む。image 行以外は表示しない
4. 試験：`python -m pytest tests`（7件）
