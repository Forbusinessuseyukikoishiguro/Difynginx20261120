const { SPEC, PN } = require((process.env.DRILL_DIR || __dirname) + '/spec.js');
const MODE = 'customer';
const COL = [C.accent1, C.accent2, C.accent6, C.accent4, C.accent3, C.accent5];
const darkOn = (i) => (i === 1 || i === 2);
const TAGC = { '公式': C.accent4, '整理': C.accent2, '確認': C.accent6, '未確認': C.accent3 };
const DIFF = [1, 3, 4, 5, 6, 7, 9, 3];
const TRK = ['1', '2', '3', '4', '5', '6', '7', '8', '下'];
const CT = 2.35, CB = 5.8;

const PCOL = ['A', 'B', 'C', 'D', 'E', '特'];
const hdr = (sp) => {
  const s = slide(sp.title, sp.part >= 0 ? PN[sp.part] : (sp.sec || 'はじめに'));
  if (sp.part >= 0) {
    PCOL.forEach((t, i) => { const now = i === sp.part, done = i < sp.part; const col = now ? C.accent1 : (done ? C.accent6 : C.accent5);
      s.addShape(SH.ROUNDED_RECTANGLE, { x: L + i * 0.6, y: 0.16, w: 0.5, h: 0.24, rectRadius: 0.05, fill: { color: col, transparency: (now || done) ? 0 : 75 }, line: { color: col, width: 0 } }); });
    T(s, 'パート' + PN[sp.part], L + 3.8, 0.12, 6, 0.32, { fontSize: 14, bold: true, color: C.accent1, valign: 'middle' });
  } else T(s, (sp.sec || 'はじめに'), L, 0.12, 6, 0.32, { fontSize: 14, bold: true, color: C.accent1, valign: 'middle' });
  if (sp.q) { tint(s, L, 1.15, W, 0.65, C.accent1, 90); T(s, 'Q. ' + sp.q, 0.85, 1.15, 11.7, 0.65, { fontSize: 20, bold: true, color: C.accent1, valign: 'middle' }); }
  if (sp.tag) { const c = TAGC[sp.tag.k]; box(s, L, 1.9, 1.15, 0.3, c); T(s, sp.tag.k, L, 1.9, 1.15, 0.3, { fontSize: 12, bold: true, color: (sp.tag.k === '整理') ? C.text2 : C.background1, align: 'center', valign: 'middle' });
    T(s, sp.tag.t, L + 1.3, 1.9, 10.8, 0.3, { fontSize: 12, color: C.accent5, valign: 'middle' }); }
  if (sp.ans) { box(s, L, 5.95, W, 0.85, C.accent2); T(s, '答えの目安', L + 0.25, 5.95, 2.2, 0.85, { fontSize: 16, bold: true, color: C.text2, valign: 'middle' });
    T(s, sp.ans, L + 2.4, 5.95, W - 2.6, 0.85, { fontSize: 18, bold: true, color: C.text2, valign: 'middle' }); }
  if (sp.hint) { tint(s, L, 6.0, W, 0.75, C.accent2, 80); T(s, 'ポイント', L + 0.25, 6.0, 1.6, 0.75, { fontSize: 15, bold: true, color: C.accent1, valign: 'middle' }); T(s, sp.hint, L + 1.9, 6.0, W - 2.1, 0.75, { fontSize: sp.hint.length > 55 ? 13 : 16, bold: true, color: C.text2, valign: 'middle' }); }
  return s;
};
const wbox2 = (s, x, y, w, h, label, ph) => {
  s.addShape(SH.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: 0.08, fill: { color: C.background1 }, line: { color: C.accent1, width: 1.5, dashType: 'dash' } });
  T(s, '【書く】' + label, x + 0.15, y + 0.08, w - 0.3, 0.6, { fontSize: 15, bold: true, color: C.accent1 });
  T(s, ph, x + 0.15, y + 0.72, w - 0.3, h - 0.8, { fontSize: 13, italic: true, color: C.accent5 });
};
const R = {
  cover(sp) {
    const s = slide(__M.coverTitle || 'ドリル\n（書き込み式）', 'スタート', 'COVER');
    T(s, (__M.coverTag || '受講生用｜書き込み式ドリル｜解答と解説つき'), 0.8, 0.7, 7.4, 0.4, { fontSize: 18, bold: true, color: C.accent2 });
    T(s, (__M.coverSub || '先に書く。そのあと、解答で確かめる'), 0.8, 1.1, 7.4, 0.4, { fontSize: 16, color: C.accent6 });
    T(s, (__M.coverQs || 'Q. 見ないで、言えますか？\nQ. 公式の事実と、講師の整理を、分けて言えますか？'), 0.8, 4.3, 7.4, 1.3, { fontSize: 18, color: C.background1, paraSpaceAfter: 8 });
    T(s, (__M.coverFoot || 'うさうさ研修工房'), 0.8, 6.5, 7, 0.4, { fontSize: 14, color: C.accent6 });
    for (let i = 0; i < 5; i++) { const h = (i + 2) * 0.6, x = 8.6 + i * 0.8; const col = i === 4 ? C.accent2 : C.accent6; s.addShape(SH.RECTANGLE, { x, y: 6.0 - h, w: 0.65, h, fill: { color: col }, line: { color: col, width: 0 } }); }
    T(s, (__M.coverBar === undefined ? 'パート A → E' : __M.coverBar), 8.6, 6.15, 4.4, 0.4, { fontSize: 16, bold: true, color: C.background1 });
  },
  wfields(sp) {
    const s = hdr(sp); const { cols, rows, items } = sp.data; const g = 0.2, bot = sp.hint || sp.ans ? 5.85 : 6.6;
    const w = (W - g * (cols - 1)) / cols, h = (bot - CT - g * (rows - 1)) / rows;
    items.forEach((it, i) => wbox2(s, L + (i % cols) * (w + g), CT + Math.floor(i / cols) * (h + g), w, h, it.h, it.ph));
  },
  wtable(sp) {
    const s = hdr(sp); const rowsD = sp.data.rows; const n = rowsD.length;
    const head = sp.data.head.map(c => ({ text: c, options: { bold: true, color: 'FFFFFF', fill: { color: '8B2D4F' }, fontSize: 12, valign: 'middle', fontFace: 'Yu Gothic', margin: [0.02, 0.08, 0.02, 0.08] } }));
    const body = rowsD.map((r, i) => r.map((c, k) => ({ text: c || '', options: { bold: false, color: '1F2937', fill: { color: (c === '' ? 'FFFFFF' : (i % 2 ? 'FBF0F3' : 'FFFFFF')) }, fontSize: 11, valign: 'middle', fontFace: 'Yu Gothic', margin: [0.02, 0.08, 0.02, 0.08] } })));
    const rh = Math.min(0.7, (5.8 - CT - 0.45) / n);
    s.addTable([head].concat(body), { x: L, y: CT, w: W, colW: sp.data.colW, rowH: [0.45].concat(rowsD.map(() => rh)), border: { type: 'solid', pt: 1, color: 'D98FA3' } });
    T(s, '※ 空白のセルは、クリックして入力できます', 8.0, 0.12, 4.9, 0.32, { fontSize: 12, color: C.accent5, align: 'right', valign: 'middle' });
  },
  road(sp) {
    const s = hdr(sp);
    const nm = __M.road || [['A', 'パートA', ''], ['B', 'パートB', ''], ['C', 'パートC', ''], ['D', 'パートD', ''], ['E', 'パートE', '']];
    nm.forEach((r, i) => { const x = 0.6 + i * 2.45; const h = 2.0 + i * 0.35, y = 5.4 - h; const col = i % 2 ? C.accent1 : C.accent6; const dk = col === C.accent6;
      s.addShape(SH.RECTANGLE, { x, y, w: 2.25, h, fill: { color: col }, line: { color: col, width: 0 } });
      T(s, 'パート' + r[0], x, y + 0.1, 2.25, 0.4, { fontSize: 18, bold: true, color: dk ? C.text2 : C.background1, align: 'center' });
      T(s, r[1], x + 0.1, y + 0.55, 2.05, 0.7, { fontSize: 16, bold: true, color: dk ? C.text2 : C.background1, align: 'center' });
      T(s, r[2], x + 0.1, y + 1.25, 2.05, 0.7, { fontSize: 12, color: dk ? C.text2 : C.background1, align: 'center' }); });
    T(s, (__M.roadMsg || '先に書く。そのあと、解答と解説で確かめる'), L, 5.75, W, 0.5, { fontSize: 18, bold: true, color: C.accent1, align: 'center' });
  },
  cards(sp) {
    const s = hdr(sp); const { cols, items } = sp.data; const rows = Math.ceil(items.length / cols), g = 0.2;
    const w = (W - g * (cols - 1)) / cols, h = ((sp.ans ? CB - CT : 6.6 - CT) - g * (rows - 1)) / rows;
    const hs = rows > 1 ? 17 : 20, bs = rows > 1 ? 13 : (cols >= 4 ? 15 : 18);
    items.forEach((it, i) => { const x = L + (i % cols) * (w + g), y = CT + Math.floor(i / cols) * (h + g); const col = COL[it.c % 6];
      tint(s, x, y, w, h, col, 86); box(s, x, y, 0.12, h, col);
      T(s, it.h, x + 0.3, y + 0.1, w - 0.45, 0.6, { fontSize: hs, bold: true, color: C.text2, valign: 'middle' });
      T(s, it.b, x + 0.3, y + 0.75, w - 0.45, h - 0.85, { fontSize: bs, paraSpaceAfter: 3 }); });
  },
  flow(sp) {
    const s = hdr(sp); const n = sp.data.nodes.length, g = 0.7, w = (W - g * (n - 1)) / n;
    sp.data.nodes.forEach((nd, i) => { const x = L + i * (w + g), col = COL[nd.c]; box(s, x, 2.6, w, 1.7, col);
      T(s, nd.t, x + 0.1, 2.75, w - 0.2, 0.7, { fontSize: 16, bold: true, color: darkOn(nd.c) ? C.text2 : C.background1, align: 'center', valign: 'middle' });
      T(s, nd.s, x + 0.1, 3.5, w - 0.2, 0.7, { fontSize: 14, color: darkOn(nd.c) ? C.text2 : C.background1, align: 'center' });
      if (i < n - 1) harrow(s, x + w + 0.05, 3.45, g - 0.1); });
    tint(s, L, 4.6, W, 1.15, C.accent3, 88); T(s, sp.data.note, L + 0.3, 4.6, W - 0.6, 1.15, { fontSize: 16, bold: true, valign: 'middle', color: C.text2 });
  },
  table(sp) {
    const s = hdr(sp); const rows = sp.data.rows;
    s.addTable(rows.map((r, i) => r.map(c => ({ text: c, options: { bold: i === 0, color: i === 0 ? 'FFFFFF' : '1F2937', fill: { color: i === 0 ? '8B2D4F' : (i % 2 ? 'FBF0F3' : 'FFFFFF') }, fontSize: i === 0 ? 16 : 14, valign: 'middle', fontFace: 'Yu Gothic', margin: [0.04, 0.1, 0.04, 0.1] } }))),
      { x: L, y: CT, w: W, colW: sp.data.colW, rowH: 0.62, border: { type: 'solid', pt: 1, color: 'D98FA3' } });
  },
  code(sp) {
    const s = hdr(sp); const lines = sp.data.code;
    mock(s, L, CT, 7.6, CB - CT, lines, null, sp.data.fs);
    const n = sp.data.side.length, h = (CB - CT - 0.2 * (n - 1)) / n;
    sp.data.side.forEach((sd, i) => { const y = CT + i * (h + 0.2); tint(s, 8.4, y, 4.33, h, COL[(i * 3 + 3) % 6], 86); T(s, sd.h, 8.6, y + 0.08, 4.0, 0.4, { fontSize: 16, bold: true, color: C.accent1 }); T(s, sd.b, 8.6, y + 0.5, 4.0, h - 0.55, { fontSize: 13, paraSpaceAfter: 3 }); });
  },
  steps(sp) {
    const s = hdr(sp); const it = sp.data.items, n = it.length, h = Math.min(0.68, (CB - CT) / n);
    it.forEach((r, i) => { const y = CT + i * h; dot(s, i + 1, L, y + (h - 0.5) / 2, i % 2 ? C.accent1 : C.accent4, 0.5);
      tint(s, 1.3, y + 0.04, 11.43, h - 0.08, C.accent1, 92);
      T(s, r[0], 1.5, y, 2.7, h, { fontSize: 16, bold: true, color: C.text2, valign: 'middle' }); T(s, r[1], 4.3, y, 8.3, h, { fontSize: 15, valign: 'middle' }); });
  },
  checks(sp) {
    const s = hdr(sp); const g = sp.data.groups, w = (W - 0.25) / 2; const mx = Math.max(...g.map(x => x.items.length));
    g.forEach((gr, k) => { const x = L + k * (w + 0.25); tint(s, x, CT, w, CB - CT, k ? C.accent4 : C.accent1, 90); T(s, gr.h, x + 0.25, CT + 0.08, w - 0.5, 0.45, { fontSize: 18, bold: true, color: k ? C.accent4 : C.accent1 });
      const rh = Math.min(0.66, (CB - CT - 0.65) / mx);
      gr.items.forEach((t, i) => { const y = CT + 0.6 + i * rh; check(s, x + 0.25, y + (rh - 0.3) / 2, k ? C.accent4 : C.accent1); T(s, t, x + 0.7, y, w - 0.95, rh, { fontSize: 15, valign: 'middle' }); }); });
  },
  reflect(sp) {
    const s = hdr(sp);
    [['わかったこと', '1つだけ書く'], ['自分の案件で使えそうなこと', '具体的に'], ['次にやること', 'いつ・何を（例：来週、check_env.py を案件の環境で動かす）']].forEach((r, i) => { const x = 0.6 + i * 4.15;
      s.addShape(SH.ROUNDED_RECTANGLE, { x, y: 2.05, w: 3.95, h: 2.6, rectRadius: 0.08, fill: { color: C.background1 }, line: { color: C.accent1, width: 1.5, dashType: 'dash' } });
      T(s, '【書く】' + r[0], x + 0.2, 2.15, 3.55, 0.8, { fontSize: 18, bold: true, color: C.accent1 }); T(s, r[1], x + 0.2, 3.0, 3.55, 1.6, { fontSize: 15, italic: true, color: C.accent5 }); });
    box(s, L, 4.9, W, 1.7, C.accent2);
    T(s, [{ text: 'ここまで来たあなたは、お客様に渡せる形で作れる人です', options: { fontSize: 26, bold: true, breakLine: true } }, { text: '未確認を隠さず伝えることも、納品の一部です', options: { fontSize: 20, bold: true, color: C.accent1 } }], L, 4.9, W, 1.7, { align: 'center', valign: 'middle', color: C.text2 });
  },
  sources(sp) {
    const s = hdr(sp);
    sp.data.links.forEach((l, i) => { const y = CT + i * 0.68; tint(s, L, y, 7.7, 0.6, C.accent4, 88); T(s, l[0], L + 0.2, y + 0.02, 6.9, 0.3, { fontSize: 13, bold: true, color: C.accent1 }); T(s, l[1], L + 0.2, y + 0.31, 6.4, 0.28, { fontSize: 10, color: C.accent5 });
      box(s, 7.35, y + 0.15, 0.8, 0.3, C.accent4); T(s, l[2], 7.35, y + 0.15, 0.8, 0.3, { fontSize: 11, bold: true, color: C.background1, align: 'center', valign: 'middle' }); });
    tint(s, 8.5, CT, 4.23, 3.45, C.accent3, 88); T(s, '未確認（お客様に出す前に確認）', 8.7, CT + 0.08, 3.9, 0.5, { fontSize: 15, bold: true, color: C.accent3 });
    T(s, sp.data.un.map((t, i) => `${i + 1}. ${t}`).join('\n'), 8.7, CT + 0.65, 3.9, 2.7, { fontSize: 13, paraSpaceAfter: 4 });
  },
};
