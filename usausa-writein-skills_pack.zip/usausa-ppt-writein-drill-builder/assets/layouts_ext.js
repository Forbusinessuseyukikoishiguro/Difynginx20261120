// 追加の書き込みレイアウト（wmatch / wsort / wscale / wbins / wcode / wcase / wchoice）
// body.js の R に足す。head.js・body.js の後ろ、render.js の前に連結される。
const __bot = (sp) => (sp.hint || sp.ans) ? 5.85 : 6.6;
const __dash = (s, x, y, w, h, o = {}) => s.addShape(SH.ROUNDED_RECTANGLE, Object.assign({ x, y, w, h, rectRadius: 0.08, fill: { color: C.background1 }, line: { color: C.accent1, width: 1.5, dashType: 'dash' } }, o));
const __KANA = ['ア', 'イ', 'ウ', 'エ', 'オ', 'カ'];
Object.assign(R, {
  // 線つなぎ（記号書き込み）: data {left:[..], right:[..], hl, hr}  左は番号、右はア・イ・ウ。答え欄に記号を書く
  wmatch(sp) {
    const s = hdr(sp); const { left, right } = sp.data; const n = Math.max(left.length, right.length), bot = __bot(sp);
    const hh = 0.35, rh = Math.min(0.72, (bot - CT - hh - 0.05) / n);
    T(s, sp.data.hl || '左（番号）', L, CT, 5.0, hh, { fontSize: 13, bold: true, color: C.accent1, valign: 'middle' });
    T(s, '【書く】記号', L + 5.15, CT, 1.5, hh, { fontSize: 12, bold: true, color: C.accent1, align: 'center', valign: 'middle' });
    T(s, sp.data.hr || '右（記号）', L + 6.95, CT, 5.0, hh, { fontSize: 13, bold: true, color: C.accent1, valign: 'middle' });
    for (let i = 0; i < n; i++) { const y = CT + hh + i * rh;
      if (left[i] !== undefined) { tint(s, L, y + 0.04, 5.0, rh - 0.08, C.accent1, 92); T(s, `${i + 1}. ${left[i]}`, L + 0.15, y, 4.75, rh, { fontSize: 14, valign: 'middle' });
        __dash(s, L + 5.3, y + 0.08, 1.2, rh - 0.16); T(s, '？', L + 5.3, y + 0.08, 1.2, rh - 0.16, { fontSize: 18, color: C.accent5, align: 'center', valign: 'middle' }); }
      if (right[i] !== undefined) { tint(s, L + 6.95, y + 0.04, 5.18, rh - 0.08, C.accent4, 90); T(s, `${__KANA[i]}. ${right[i]}`, L + 7.1, y, 4.95, rh, { fontSize: 14, valign: 'middle' }); } }
  },
  // 並べ替え: data {items:[..(わざと順不同)], cols}  各カードの丸に順番を書く
  wsort(sp) {
    const s = hdr(sp); const it = sp.data.items, cols = sp.data.cols || 3, rows = Math.ceil(it.length / cols), g = 0.2, bot = __bot(sp);
    const w = (W - g * (cols - 1)) / cols, h = (bot - CT - g * (rows - 1)) / rows;
    it.forEach((t, i) => { const x = L + (i % cols) * (w + g), y = CT + Math.floor(i / cols) * (h + g);
      tint(s, x, y, w, h, C.accent4, 90);
      s.addShape(SH.OVAL, { x: x + 0.15, y: y + (h - 0.7) / 2, w: 0.7, h: 0.7, fill: { color: C.background1 }, line: { color: C.accent1, width: 1.5, dashType: 'dash' } });
      T(s, '？', x + 0.15, y + (h - 0.7) / 2, 0.7, 0.7, { fontSize: 20, color: C.accent5, align: 'center', valign: 'middle' });
      T(s, t, x + 1.0, y + 0.05, w - 1.15, h - 0.1, { fontSize: 15, valign: 'middle' }); });
  },
  // 自己評価 1〜5: data {rows:[..], lo, hi}  数字の丸を色で塗る＋ひとこと欄
  wscale(sp) {
    const s = hdr(sp); const rows = sp.data.rows, n = rows.length, bot = __bot(sp), hh = 0.38, rh = Math.min(0.72, (bot - CT - hh) / n);
    T(s, '1＝' + (sp.data.lo || 'まだ') + '　→　5＝' + (sp.data.hi || 'できる') + '　（当てはまる丸を色で塗る）', L, CT, 7.6, hh, { fontSize: 12, bold: true, color: C.accent1, valign: 'middle' });
    T(s, '【書く】ひとこと', L + 9.0, CT, 3.1, hh, { fontSize: 12, bold: true, color: C.accent1, valign: 'middle' });
    rows.forEach((t, i) => { const y = CT + hh + i * rh;
      tint(s, L, y + 0.04, 5.2, rh - 0.08, C.accent1, 92); T(s, t, L + 0.15, y, 4.95, rh, { fontSize: 14, valign: 'middle' });
      for (let k = 0; k < 5; k++) { const d = Math.min(0.5, rh - 0.14), x = L + 5.5 + k * 0.68;
        s.addShape(SH.OVAL, { x, y: y + (rh - d) / 2, w: d, h: d, fill: { color: C.background1 }, line: { color: C.accent1, width: 1.5 } });
        T(s, String(k + 1), x, y + (rh - d) / 2, d, d, { fontSize: 13, bold: true, color: C.accent1, align: 'center', valign: 'middle' }); }
      __dash(s, L + 9.0, y + 0.06, 3.13, rh - 0.12); });
  },
  // 仕分け: data {chips:[..], bins:[{h, ph}]}  チップの言葉を、分類の枠に書き写す
  wbins(sp) {
    const s = hdr(sp); const { chips, bins } = sp.data, bot = __bot(sp), g = 0.15;
    const cw = (W - g * (chips.length - 1)) / chips.length;
    chips.forEach((c, i) => { const x = L + i * (cw + g); box(s, x, CT, cw, 0.5, C.accent6); T(s, c, x, CT, cw, 0.5, { fontSize: chips.length > 5 ? 12 : 14, bold: true, color: C.text2, align: 'center', valign: 'middle' }); });
    const bw = (W - 0.2 * (bins.length - 1)) / bins.length, y0 = CT + 0.7;
    bins.forEach((b, i) => { const x = L + i * (bw + 0.2); __dash(s, x, y0, bw, bot - y0);
      T(s, b.h, x + 0.15, y0 + 0.08, bw - 0.3, 0.5, { fontSize: 16, bold: true, color: C.accent1 });
      T(s, '【書く】' + (b.ph || 'ここに言葉を書き写す'), x + 0.15, y0 + 0.65, bw - 0.3, bot - y0 - 0.75, { fontSize: 13, italic: true, color: C.accent5 }); });
  },
  // コード穴埋め: data {fs, code:[{t,c}], blanks:[{h, ph}]}  （1）（2）の空欄に書く
  wcode(sp) {
    const s = hdr(sp); const bot = __bot(sp);
    mock(s, L, CT, 7.6, bot - CT, sp.data.code, null, sp.data.fs);
    const n = sp.data.blanks.length, h = (bot - CT - 0.2 * (n - 1)) / n;
    sp.data.blanks.forEach((b, i) => wbox2(s, 8.4, CT + i * (h + 0.2), 4.33, h, b.h, b.ph || ''));
  },
  // 事例分析: data {case:'事例の文', boxes:[{h, ph}]}  左に事例、右に書く枠
  wcase(sp) {
    const s = hdr(sp); const bot = __bot(sp), n = sp.data.boxes.length, h = (bot - CT - 0.2 * (n - 1)) / n;
    tint(s, L, CT, 5.4, bot - CT, C.accent2, 86); T(s, '事例', L + 0.2, CT + 0.1, 5.0, 0.4, { fontSize: 16, bold: true, color: C.accent1 });
    T(s, sp.data.case, L + 0.2, CT + 0.6, 5.0, bot - CT - 0.7, { fontSize: 15, paraSpaceAfter: 6 });
    sp.data.boxes.forEach((b, i) => wbox2(s, L + 5.6, CT + i * (h + 0.2), W - 5.6, h, b.h, b.ph || ''));
  },
  // 選択式（□を■に書き換える）＋その他: data {cols, qs:[{h, opts:[..]}]}  事前ヒアリング向け
  wchoice(sp) {
    const s = hdr(sp); const { qs } = sp.data, cols = sp.data.cols || 2, rows = Math.ceil(qs.length / cols), g = 0.2, bot = __bot(sp);
    const w = (W - g * (cols - 1)) / cols, h = (bot - CT - g * (rows - 1)) / rows;
    T(s, '※ □を ■ に書き換えて選ぶ（複数可は、そのように書いてある設問のみ）', 5.0, 0.12, 7.9, 0.32, { fontSize: 12, color: C.accent5, align: 'right', valign: 'middle' });
    qs.forEach((q, i) => { const x = L + (i % cols) * (w + g), y = CT + Math.floor(i / cols) * (h + g);
      __dash(s, x, y, w, h);
      T(s, q.h, x + 0.2, y + 0.08, w - 0.4, 0.42, { fontSize: 15, bold: true, color: C.accent1 });
      const lines = q.opts.map(o => '□ ' + o).concat(['□ その他：＿＿＿＿＿']);
      T(s, lines.join('\n'), x + 0.25, y + 0.55, w - 0.5, h - 0.6, { fontSize: lines.length > 5 ? 12 : 14, paraSpaceAfter: 3 }); });
  },
});
