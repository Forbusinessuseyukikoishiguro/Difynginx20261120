const pptxgen = require('pptxgenjs');
const { applyTheme } = require('/mnt/skills/public/pptx/scripts/apply_theme.js');
const FONT = 'Yu Gothic';
const THEME = { name: 'Usausa Rose Dify Prework', headFontFace: FONT, bodyFontFace: FONT,
  colors: { dk1: '1F2937', lt1: 'FFFFFF', dk2: '3D1228', lt2: 'FBF0F3',
    accent1: '8B2D4F', accent2: 'C9A227', accent3: 'D9482B', accent4: '5B8C5A', accent5: '5B6B7F', accent6: 'D98FA3',
    hlink: '8B2D4F', folHlink: '5B6B7F' } };
const pres = new pptxgen();
pres.layout = 'LAYOUT_WIDE';
pres.theme = { headFontFace: FONT, bodyFontFace: FONT };
const __M = (require((process.env.DRILL_DIR || __dirname) + '/spec.js').META) || {};
pres.title = __M.deckTitle || 'ドリル（書き込み式）';
pres.author = 'うさうさ研修工房';
const C = pres.SchemeColor, SH = pres.shapes;
const L = 0.6, W = 12.13;
const FOOT = __M.foot || 'うさうさ研修工房｜ドリル（書き込み式）';

pres.defineSlideMaster({ title: 'CONTENT', background: { color: C.background1 },
  slideNumber: { x: 12.2, y: 6.98, w: 0.6, h: 0.3, fontSize: 10, color: C.accent5 },
  objects: [
    { placeholder: { options: { name: 'title', type: 'title', x: L, y: 0.5, w: W, h: 0.8, fontSize: 30, bold: true, color: C.text2, valign: 'middle', margin: 0, align: 'left' }, text: '' } },
    { text: { text: FOOT, options: { x: L, y: 6.98, w: 6, h: 0.3, fontSize: 10, color: C.accent5, margin: 0, fontFace: FONT } } } ] });
pres.defineSlideMaster({ title: 'COVER', background: { color: C.accent1 },
  objects: [ { placeholder: { options: { name: 'title', type: 'title', x: 0.8, y: 1.7, w: 7.2, h: 2.3, fontSize: 44, bold: true, color: C.background1, valign: 'top', margin: 0, align: 'left' }, text: '' } } ] });

const T = (s, text, x, y, w, h, o = {}) => s.addText(text, Object.assign({ x, y, w, h, fontSize: 14, color: C.text1, margin: 0, valign: 'top', isTextBox: true, fontFace: FONT }, o));
const box = (s, x, y, w, h, fill, o = {}) => s.addShape(SH.ROUNDED_RECTANGLE, Object.assign({ x, y, w, h, rectRadius: 0.08, fill: { color: fill }, line: { color: fill, width: 0 } }, o));
const tint = (s, x, y, w, h, color, tr = 88) => s.addShape(SH.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: 0.08, fill: { color, transparency: tr }, line: { color, width: 0 } });
const harrow = (s, x, y, w, color) => s.addShape(SH.LINE, { x, y, w, h: 0, line: { color: color || C.accent5, width: 2.25, endArrowType: 'triangle' } });
const varrow = (s, x, y, h, color) => s.addShape(SH.LINE, { x, y, w: 0, h, line: { color: color || C.accent5, width: 2.25, endArrowType: 'triangle' } });
const dot = (s, n, x, y, color, d = 0.5) => { s.addShape(SH.OVAL, { x, y, w: d, h: d, fill: { color }, line: { color, width: 0 } });
  T(s, String(n), x, y, d, d, { fontSize: 16, bold: true, color: C.background1, align: 'center', valign: 'middle' }); };
const wbox = (s, x, y, w, h, label, ph, o = {}) => {
  s.addShape(SH.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: 0.08, fill: { color: C.background1 }, line: { color: C.accent1, width: 1.5, dashType: 'dash' } });
  T(s, [{ text: '【書く】' + label, options: { bold: true, color: C.accent1, breakLine: true } }, { text: ph || 'ここをクリックして書き込む', options: { color: C.accent5, italic: true } }],
    x + 0.2, y + 0.12, w - 0.4, h - 0.24, Object.assign({ fontSize: 14, paraSpaceAfter: 4 }, o));
};
const check = (s, x, y, color) => s.addShape(SH.RECTANGLE, { x, y, w: 0.3, h: 0.3, fill: { color: C.background1 }, line: { color: color || C.accent1, width: 2 } });
const mock = (s, x, y, w, h, lines, border, fs = 14) => {
  s.addShape(SH.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: 0.08, fill: { color: C.text2 }, line: { color: border || C.text2, width: border ? 2.5 : 0 } });
  const runs = lines.map((l, i) => ({ text: l.t || ' ', options: { color: l.c || C.background1, bold: !!l.b, breakLine: i < lines.length - 1 } }));
  T(s, runs, x + 0.25, y + 0.18, w - 0.5, h - 0.36, { fontSize: fs, color: C.background1, paraSpaceAfter: 2 });
};
let sec = '';
const slide = (title, section, master = 'CONTENT') => {
  if (section) { sec = section; pres.addSection({ title: section }); }
  const s = pres.addSlide({ masterName: master, sectionTitle: sec });
  if (title) s.addText(title, { placeholder: 'title' });
  return s;
};
const q = (s, text) => { tint(s, L, 1.15, W, 0.6, C.accent1, 90); T(s, 'Q. ' + text, 0.85, 1.15, 11.6, 0.6, { fontSize: 18, bold: true, color: C.accent1, valign: 'middle' }); };
const step = (n, diff, title, qtext, section) => {
  const s = slide(title, section);
  T(s, `STEP ${n}｜難易度 ${'●'.repeat(diff)}${'○'.repeat(8 - diff)}`, L, 0.12, 8, 0.3, { fontSize: 12, bold: true, color: C.accent1 });
  q(s, qtext); return s;
};
const tag = (s, text) => { T(s, text, L, 0.12, 8, 0.3, { fontSize: 12, bold: true, color: C.accent1 }); };
